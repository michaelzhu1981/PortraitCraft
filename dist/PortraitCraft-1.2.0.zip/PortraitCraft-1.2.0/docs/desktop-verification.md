# Desktop verification history

Date: 2026-10-11, Asia/Shanghai.

Host: `/Applications/PhotoCraft.app`, version 0.7.0, source commit `79261615956ab21334e49ca1d384390272e647da`.

## Original release

These checks preceded the rename to PortraitCraft:

- Installed `dist/portrait-smooth.wasm` through Filter → Plug-ins → Install Plug-in.
- The original Portrait Smooth menu entry appeared, with its original Chinese display name.
- Opened the parameter dialog on the generated `tests/output/input.png`; all 20 parameters and the Preview, Cancel, and OK controls were accessible.
- Applied the filter successfully and confirmed that undo worked without a processing error.
- Closed the test image without overwriting its source file. The module remained loaded in that process.
- Host preferences were not modified. README describes optional loading after restart.

This was a desktop integration check, not a portrait-quality evaluation. Numerical, bit-depth, selection, Smart Object, and timing records are in `verification.json`.

## Rename to PortraitCraft

- The project moved to `/Users/zhuxiaolong/Documents/Projects/PortraitCraft`.
- The manifest name became PortraitCraft and the module became `dist/PortraitCraft.wasm`.
- The renamed module passed nine official PhotoCraft CLI checks and 16 WebAssembly checks at that stage.
- That work did not reload the module in the running desktop process. Reinstallation is required to refresh its menu entry.

## Complete presets in 1.1.0

- Gentle, Natural, and Strong became complete smoothing recipes. Custom mode, threshold, and automatic scale were added.
- Twenty WebAssembly checks, 13 official CLI checks, and four batch checks passed.
- For the synthetic pores/medium-scale fixture, residual mean-square error was approximately 88.7%, 53.0%, and 19.2% of the original, respectively. These values demonstrate strength ordering for that fixture, not real-portrait quality scores.
- The pinned `plugin_ui.rs`, `manifest.rs`, and `filter_dialog.rs` confirm that parameters cannot update one another and that the generated dialog does not display the manifest description. Seven smoothing controls apply only in Custom mode.
- `plugin.run` can preview a downsampled proxy document; the module receives no proxy multiplier. The plugin did not change this host behavior.
- `proxy.rs` confirms that disabling Preferences → Performance → Low Resolution Previews uses full resolution. With that setting enabled, documents larger than 5 MP are downsampled. Host preferences were not modified.
- The new presets were not visually tested in the desktop application or on real portraits.

## Ordering in 1.1.1

The preset default changed to Gentle so that the host's default-first ordering produced Gentle → Natural → Strong → Custom. Twenty WebAssembly and 13 official CLI checks passed. The batch helper retained Natural as its default.

## English text in 1.2.0

Project documentation, CLI help, and plugin-authored preset, mask, and view choices use English. The batch helper converts legacy Chinese choice values before passing them to the host. Saved Smart Filter values are not automatically migrated.

- Twenty WebAssembly checks, 13 official CLI checks, and five batch checks passed.
- Default, Gentle, Natural, Strong, and skin-mask outputs were compared against the saved 1.1.1 host outputs. All five were pixel-identical, confirming that changing the choice strings did not change processing for these fixtures.
- The current Markdown documentation, manifest, preset JSON files, and generated verification JSON contain no Chinese text. Chinese strings remain in compatibility code and regression tests for legacy parameter files.

PhotoCraft renders its built-in labels in its selected language; Auto follows the system. ABI v1 has no general plugin localization or tooltip API. This release does not rebuild the host and does not claim complete localization of custom plugin strings.

Current automated evidence is in `verification.json`. Desktop reinstallation and visual language verification remain unperformed. The current module must be reinstalled before changes can appear in an already running PhotoCraft process.

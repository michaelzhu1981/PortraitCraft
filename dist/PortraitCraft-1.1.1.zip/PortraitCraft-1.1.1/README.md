# PortraitCraft · PhotoCraft 人像精修

可直接安装的 PhotoCraft WebAssembly 滤镜。提供与 Portraiture 3 工作流相近的分级磨皮、肤色范围蒙版、纹理/边缘保护及肤色调整；算法为本项目独立实现，**不等同于 Imagenomic Portraiture 3 的算法、效果或完整功能复刻**。

交付文件：[`dist/PortraitCraft.wasm`](dist/PortraitCraft.wasm)，版本 **1.1.1**。已通过 PhotoCraft **0.7.0 / ABI v1** 官方 CLI 集成验证。桌面加载、参数窗口、应用与撤销的历史验证针对初版；本次新版尚未在桌面重新安装和验证。安装本插件不需要 Python、Node、Zig 或联网；开发和批处理另需对应工具。

## 安装和使用

1. PhotoCraft → **滤镜 → 插件 → 安装插件…**。
2. 在“路径”填入 `.wasm` 的完整路径并确定。本机路径：
   ```text
   /Users/zhuxiaolong/Documents/Projects/PortraitCraft/dist/PortraitCraft.wasm
   ```
3. 打开照片，确认 **图像 → 模式 → RGB 颜色**，选中需要处理的像素图层。建议先复制图层，或先转换为智能对象以保留可编辑的滤镜。
4. 选择 **滤镜 → 插件 → PortraitCraft…**，默认“轻柔”，也可选择“自然”或“精修”，在 100% 缩放下检查皮肤纹理。
5. 在 `view`（视图）中选择“肤色蒙版”或“红色叠加”，调整 `tolerance`，必要时先用 PhotoCraft 选区限制人像范围。
6. **将视图切回“效果”后再确定**。蒙版、叠加和左右对比都是滤镜输出模式，直接确定会把它们写进图层。勾选“预览”可查看效果，取消不提交。

PhotoCraft 的“安装”仅加载到当前进程。重启后若需自动加载，在 **编辑 → 首选项 → 插件** 中启用“使用附加插件文件夹”，并将文件夹设为本项目的 `dist`（不能填 `.wasm` 文件本身）。本项目没有修改你的首选项。

更名后，请按上述步骤重新安装 `PortraitCraft.wasm`，宿主会刷新菜单名称。内部插件 ID 保持稳定，因此重新安装会替换旧版本，并保留已有智能滤镜对该插件的引用。

## 1.1.0 预设与预览

1.1.1 将下拉顺序固定为 **轻柔 → 自然 → 精修 → 自定义**。PhotoCraft 0.7.0 会把默认项置顶，因此桌面默认同步改为“轻柔”。批处理脚本仍保持原来的默认“自然”，可用 `--preset 轻柔` 显式指定。

原来的预设只乘以 0.65 / 1 / 1.35 的系数，容易被纹理保护和边缘保护抵消。现在每个预设使用完整磨皮方案：轻柔保留较多纹理，自然兼顾纹理与肤色均匀度，精修加强中、大尺度处理。三档都不自动改变肤色、亮度或蒙版范围。

| 方案 | fine | medium | large | texture | edge | threshold | scale |
|---|---:|---:|---:|---:|---:|---:|---|
| 轻柔 | 55 | 30 | 10 | 65 | 85 | 20 | 自动 |
| 自然 | 85 | 65 | 35 | 35 | 75 | 45 | 自动 |
| 精修 | 100 | 90 | 65 | 15 | 65 | 70 | 自动，至少 2 |

**切换预设会改变实际处理参数，但宿主不能同步回写、隐藏或禁用下方滑块。** `fine / medium / large / texture / edge / threshold / scale` 仅在 `preset=自定义` 时生效；`amount`、蒙版、调色、锐化和视图始终可调。自定义的初始值与自然预设相同，切换到自定义不会自动拷贝其他预设；要细调轻柔或精修，可按上表填写。默认 `amount=85`，可降低以减轻修饰。

`scale=0` 根据当前处理画布面积选取倍率：小于 4 MP 为 1，4–10 MP 为 2，10–20 MP 为 3，20 MP 及以上为 4。这是按图像尺寸适配，并非检测脸部大小。精修预设至少使用倍率 2。

建议在相同的蒙版、强度和缩放下比较三档，使用 `view=左右对比` 或宿主“预览”开关查看差异。先检查肤色蒙版是否覆盖皮肤；若没有覆盖，提高容差或使用取样肤色。比较完成后将 `view` 切回“效果”。

**PhotoCraft 0.7.0 默认启用低分辨率预览，大于 5 MP 的文档会使用缩小的代理图。** 缩小时细纹本身就会减少，因此预览与最终处理可能不同。请在 **编辑 → 首选项 → 性能 → Low Resolution Previews（低分辨率预览）** 关闭该选项，再打开滤镜并在 100% 缩放下比较预设。这样宿主会以原尺寸生成预览，计算时间也会增加。仅放大画布不能替代关闭此选项。也可在复制图层上应用，再对比原图。插件接口不能自行切换这个宿主设置，本次没有修改你的首选项。

升级会改变已有预设的处理结果；原有智能滤镜中的七项磨皮滑块需切换为“自定义”才参与计算。新版阈值和纹理公式也有变化，不承诺复现 1.0.0 的旧结果。

## 参数

PhotoCraft ABI v1 不提供自定义参数标签。窗口由宿主生成，部分参数会显示宿主的中文翻译，部分仍为英文；下表列出准确的参数键。

| 参数 | 用途 |
|---|---|
| `preset` | 轻柔 / 自然 / 精修三套完整方案，或自定义；具体数值及滑块适用范围见上节 |
| `amount` | 0–100，整个修饰效果与原图的混合强度；0 完全保留原图（蒙版/叠加视图除外） |
| `fine` / `medium` / `large` | 自定义：细、中、大尺度平滑量，分别作用于局部细节与更宽的肤色起伏 |
| `scale` | 自定义：0 自动，1–4 固定倍率；三个邻域半径为 `2/5/12 × 实际倍率` 像素 |
| `texture` | 自定义：纹理保护；越高，细节和中尺度的平滑越弱 |
| `edge` | 自定义：边缘保护；越高，高局部方差区域越少平滑 |
| `threshold` | 自定义：平滑阈值；越高，越明显的局部肤色起伏也会被平滑；0 并非关闭磨皮 |
| `mask` | 自动肤色 / 取样肤色 / 全图；全图模式适合配合宿主的人像选区使用 |
| `tolerance` | 肤色色度范围容差；越大覆盖越广 |
| `sampleR/G/B` | 0–255，取样肤色模式的参考颜色；可用宿主吸管读出皮肤 RGB 后输入 |
| `warmth` | −100 到 100，冷暖偏移；负值偏冷、正值偏暖 |
| `tint` | −100 到 100，绿/品红偏移 |
| `brightness` / `contrast` / `saturation` | −100 到 100，亮度、对比度、饱和度；0 为不调整 |
| `sharpen` | 0–100，受肤色范围约束的细节锐化；默认 0 |
| `view` | 效果 / 肤色蒙版 / 红色叠加 / 左右对比（画布左侧原图，右侧效果） |

所有调色和锐化均受肤色蒙版与总强度约束。透明度原样保留；透明像素的隐藏颜色不参与邻域平滑。

## 能力边界

- **RGB 8、16、32 位**：内部使用宿主提供的 f32；32 位输出不强行裁切到 0–1。CMYK、Lab、灰度、索引色及单独的 Alpha/快速蒙版目标会明确报错（错误码 2），请切换回 RGB 图层。不能直接处理相机 RAW，需先在宿主显影。
- **肤色识别是色度启发式**，没有人脸模型。暖色背景、木材和服装可能被选中；彩色灯光、极深肤色、强过曝可能漏选。结合宿主选区或取样肤色进行修正；并未保证自动排除眼睛、嘴唇、头发。
- 平滑能减轻细碎噪点与肤色起伏，但不能取代修复画笔去除明显痘痘、疤痕或杂物。参数值与 Portraiture 的数值没有一一对应关系。
- ABI v1 仅有滤镜，**无法提供 Portraiture 式独立面板、插件内吸管、画笔蒙版或自动新建输出图层**。使用宿主的吸管、选区、复制图层与智能对象。参数预设 JSON 供命令行读取，宿主窗口没有 JSON 导入入口。
- 肤色分类按显示范围的 RGB 估计；广色域和线性 HDR 的颜色观感需要按照片调整，插件不自行读取或转换 ICC 配置。
- 插件在宿主沙箱内离线运行，不读取文件、不上传照片。大图处理仍受宿主内存和运行时间限制；时间与机器、图像尺寸、图层范围有关。

## 单张与批量处理

需从 [PhotoCraft 官方发布页](https://github.com/storytold/photocraft/releases/tag/v0.7.0) 安装 `photocraft-cli`；本开发目录的 `.tools` 已下载官方 macOS 0.7.0 CLI，仅用于本机，不纳入发布包。

在项目目录执行（Python 3.10+）：

```sh
python3 scripts/retouch.py '/照片/人像.jpg' '/输出/人像-精修.png'
python3 scripts/retouch.py '/照片/原片目录' '/输出/精修目录' --params presets/gentle.json
python3 scripts/retouch.py '/照片/人像.tif' '/输出/精修.tif' --preset 精修 --cli '/工具/photocraft-cli'
python3 scripts/retouch.py '/照片/人像.jpg' '/输出/手动精修.png' --params presets/custom-natural.json
```

不递归处理子目录；批量文件名保留源扩展名，如 `a.jpg.retouched.png`，避免同名 JPEG/TIFF 相互覆盖。脚本拒绝覆盖已有输出，也拒绝用蒙版或对比视图导出。RGB 模式不自动转换；失败会报告文件名并返回非零退出码。

**PSD/PCraft 只处理当前活动图层/智能对象，不逐层修饰整个文档**。PNG/JPEG 和默认 TIFF 是合成导出，保留图层请选择 `.pcraft`。32 位结果建议通过宿主保存为支持浮点的格式；PNG/JPEG 会降低位深。

## 构建与验证

开发依赖：Python 3.10+、Zig 0.13.0、Node.js 20+；宿主集成测试另需 NumPy、Pillow 与 PhotoCraft CLI。首次获取编译器需要联网，此后构建不需要第三方 C 库或 WASI。

```sh
python3 -m pip install --target .tools ziglang==0.13.0
python3 scripts/build.py
node --test tests/wasm.test.mjs
python3 tests/host_integration.py --cli '/工具/photocraft-cli'
python3 tests/test_cli.py
python3 scripts/package.py
```

如已安装 Zig，可通过 `ZIG` 环境变量指定其可执行路径。构建生成 `dist/PortraitCraft.wasm` 和 `dist/SHA256SUMS`。宿主测试依赖可用 `python3 -m pip install numpy pillow` 安装。批处理测试在宿主测试之后运行，且要求 CLI 位于 PATH 或本机 `.tools` 默认路径。

测试覆盖：ABI/无导入校验，零强度无损，预设强度分级，阈值与边缘保护，基于画布尺寸的自动尺度，非肤色保留，纹理保护，各档及调色参数生效，透明边缘，高位深/HDR，NaN/Inf 隔离，拒绝非 RGB，最大半径分块无缝，画布坐标对比视图。真实宿主覆盖三档预设、自定义、安装、处理、导出、撤销、蒙版、16/32 位、选区、智能对象和跨分块处理。结果见 [`docs/verification.json`](docs/verification.json)。

使用的是确定性合成测试图，**尚未完成多肤色真实人像的主观质量评测，也未与正版 Portraiture 做图像效果对照**。源码、测试和可安装二进制均已提供，方便继续按真实照片调整。

## 实现与接口依据

`src/portrait.c` 使用三尺度、由肤色和 Alpha 加权的局部均值/二阶矩，通过局部方差保护边缘，再进行分频组合与蒙版混合。横向/纵向滑动求和使每档复杂度为 O(像素数)，不会随邻域面积平方增长。计算最大半径为 48 像素，manifest 声明相同 overlap，保证宿主各分块有足够邻域；累计使用双精度降低长行漂移。

- [PhotoCraft 0.7.0 插件 ABI 文档（已固定提交）](https://github.com/storytold/photocraft/blob/79261615956ab21334e49ca1d384390272e647da/docs/plugins.md)
- [Imagenomic Portraiture 官方介绍](https://www.imagenomic.com/Products/Portraiture)（功能方向参考，当前页面可能介绍更新版本）
- [Imagenomic 官方教程](https://www.imagenomic.com/Support/Tutorials)（含 Portraiture 3 Overview 入口）
- [Portraiture 2 官方用户手册](https://www.imagenomic.com/StaticFiles/Portraiture2PluginUsersGuide.pdf)（公开说明成套预设、三档细节平滑、阈值和图像尺寸适配；是早期版本资料，不是 Portraiture 3 的算法说明。本文参数和公式均由本项目独立设计）
- [PhotoCraft 0.7.0 预览实现](https://github.com/storytold/photocraft/blob/79261615956ab21334e49ca1d384390272e647da/crates/ui-egui/src/filter_dialog.rs)（`preview_factor` / `preview_document_with`）
- [PhotoCraft 0.7.0 低分辨率预览设置](https://github.com/storytold/photocraft/blob/79261615956ab21334e49ca1d384390272e647da/crates/ui-egui/src/proxy.rs)（关闭后以完整尺寸运行）

Portraiture / Imagenomic / PhotoCraft 为各自所有者的名称。本项目不包含 Imagenomic 代码、模型或其他产品资源，与其没有隶属关系。

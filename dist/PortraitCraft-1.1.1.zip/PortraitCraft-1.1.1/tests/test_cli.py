"""Exercise the public retouch entry point, including source preservation."""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]

class RetouchCLI(unittest.TestCase):
    def call(self,*args):
        return subprocess.run([sys.executable,str(ROOT/"scripts/retouch.py"),*map(str,args)],capture_output=True,text=True)

    def test_batch_keeps_same_stem_inputs_distinct(self):
        with tempfile.TemporaryDirectory(dir=ROOT/"tests/output") as folder:
            base=Path(folder); source=base/"in"; source.mkdir()
            original=(ROOT/"tests/output/input.png").read_bytes()
            # Same image encoding, different filename suffixes; PhotoCraft sniffs PNG.
            for name in ("photo.png","photo.jpg"): (source/name).write_bytes(original)
            r=self.call(source,base/"out")
            self.assertEqual(r.returncode,0,r.stderr)
            self.assertEqual({f.name for f in (base/"out").iterdir()}, {"photo.png.retouched.png","photo.jpg.retouched.png"})
            self.assertTrue(all(f.read_bytes()==original for f in source.iterdir()))

    def test_existing_output_is_preserved(self):
        with tempfile.TemporaryDirectory(dir=ROOT/"tests/output") as folder:
            target=Path(folder)/"out.png"; target.write_bytes(b"keep me")
            r=self.call(ROOT/"tests/output/input.png",target)
            self.assertNotEqual(r.returncode,0); self.assertEqual(target.read_bytes(),b"keep me")

    def test_same_input_output_is_rejected(self):
        src=ROOT/"tests/output/input.png"; before=src.read_bytes()
        r=self.call(src,src); self.assertNotEqual(r.returncode,0); self.assertEqual(src.read_bytes(),before)

    def test_mask_export_is_rejected(self):
        with tempfile.TemporaryDirectory(dir=ROOT/"tests/output") as folder:
            folder=Path(folder); params=folder/"params.json"; params.write_text('{"view":"肤色蒙版"}')
            r=self.call(ROOT/"tests/output/input.png",folder/"out.png","--params",params)
            self.assertNotEqual(r.returncode,0); self.assertFalse((folder/"out.png").exists())

if __name__=="__main__": unittest.main()

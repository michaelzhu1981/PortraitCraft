#!/usr/bin/env python3
"""Apply PortraitCraft through PhotoCraft CLI, preserving source files."""
import argparse
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
ID = "io.photocraft.portrait-smooth"

def main():
    p=argparse.ArgumentParser(description="PhotoCraft 人像精修：单张或整个文件夹，另存结果")
    p.add_argument("input",type=Path,help="图像文件或图像文件夹（不递归）")
    p.add_argument("output",type=Path,help="单张输出文件或批量输出文件夹")
    p.add_argument("--preset",choices=["轻柔","自然","精修","自定义"],default="自然")
    p.add_argument("--params",type=Path,help="JSON 参数文件，字段见 README")
    p.add_argument("--cli",help="photocraft-cli 路径；默认从 PATH 或项目 .tools 查找")
    p.add_argument("--format",choices=["png","tif","jpg","pcraft"],default="png",help="批量输出格式")
    args=p.parse_args()
    cli=args.cli or shutil.which("photocraft-cli")
    fallback=ROOT / ".tools/photocraft/photocraft-cli-0.7.0-macos-universal/photocraft-cli"
    if not cli and fallback.is_file(): cli=str(fallback)
    if not cli: p.error("未找到 photocraft-cli；请从 PhotoCraft 官方下载 CLI 并传入 --cli")
    source=args.input.resolve(); dest=args.output.resolve()
    if not source.exists(): p.error("输入不存在")
    if source==dest: p.error("输出必须与输入分开")
    config={"preset":args.preset,"view":"效果"}
    if args.params:
        try:
            extra=json.loads(args.params.read_text())
            if not isinstance(extra,dict): raise ValueError("JSON 根节点必须是对象")
            config.update(extra)
        except (OSError,ValueError) as exc: p.error(str(exc))
    if config.get("view")!="效果": p.error("导出须使用 view=效果；请在桌面插件中检查蒙版或对比")
    schema=json.loads((ROOT / "manifest.json").read_text())["params"]
    unknown=set(config)-set(schema)
    if unknown: p.error(f"未知参数：{', '.join(sorted(unknown))}")
    wasm=ROOT / "dist/PortraitCraft.wasm"
    if not wasm.is_file(): p.error("请先执行 python3 scripts/build.py")
    if source.is_dir():
        if dest.exists() and not dest.is_dir(): p.error("批量输出必须是文件夹")
        extensions={".png",".jpg",".jpeg",".tif",".tiff",".webp",".psd",".pcraft"}
        files=sorted(f for f in source.iterdir() if f.is_file() and f.suffix.lower() in extensions)
        if not files: p.error("输入文件夹中没有支持的图像")
        jobs=[(f,dest/(f.name+".retouched."+args.format)) for f in files]
    else:
        jobs=[(source,dest)]
    # Preflight the whole batch so an existing output cannot be replaced.
    for src,out in jobs:
        if out.exists(): p.error(f"输出已存在，未覆盖：{out}")
        if src==out: p.error("不允许覆盖原图")
    failures=[]
    for src,out in jobs:
        out.parent.mkdir(parents=True,exist_ok=True)
        cmd=[cli,"run",str(src),"--cmd","plugin.install","--params",json.dumps({"path":str(wasm)}),
             "--cmd","plugin.run","--params",json.dumps({"id":ID,"params":config},ensure_ascii=False),"--out",str(out)]
        print(f"处理 {src.name} → {out.name}",flush=True)
        result=subprocess.run(cmd,capture_output=True,text=True)
        if result.returncode:
            failures.append(src.name); print(result.stderr or result.stdout,file=sys.stderr)
        else: print(f"完成：{out}")
    if failures: raise SystemExit(f"{len(failures)} 个文件失败：{', '.join(failures)}")

if __name__=="__main__": main()

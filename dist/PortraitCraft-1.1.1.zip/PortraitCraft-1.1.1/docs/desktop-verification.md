# 桌面验证记录

以下是更名前首次开发的验证记录；项目和插件现名为 PortraitCraft。

日期：2026-10-11（Asia/Shanghai）

宿主：本机 `/Applications/PhotoCraft.app`，版本 0.7.0，构建提交 `79261615956ab21334e49ca1d384390272e647da`。

- 通过“滤镜 → 插件 → 安装插件”读取项目 `dist/portrait-smooth.wasm`。
- 插件菜单出现“人像精修 · Portrait Smooth…”。
- 在项目生成的 `tests/output/input.png` 上打开参数窗口，20 个参数及“预览 / 取消 / 确定”均可访问。
- 确定成功应用滤镜；可撤销，未出现处理错误。
- 关闭验证图，没有覆盖磁盘上的测试原图；保留插件在当前宿主进程中。
- 没有修改宿主首选项；重启自动加载的设置方法见 README。

本记录为桌面集成检查。数值回归、位深、选区、智能对象与耗时证据在 `verification.json`；真实人像观感尚未评估。

## PortraitCraft 更名验证

- 项目目录现为 `/Users/zhuxiaolong/Documents/Projects/PortraitCraft`。
- manifest 名称为 `PortraitCraft`，发布文件为 `dist/PortraitCraft.wasm`。
- 真实 PhotoCraft 0.7.0 CLI 成功加载更名后的模块，9 项宿主检查通过；WebAssembly 测试 16 项通过。
- 当前运行中的桌面插件尚未重新加载新版；请重新安装新路径的文件以刷新菜单。

## 1.1.0 预设升级验证

- 轻柔、自然、精修改为完整磨皮方案；新增自定义模式、阈值与自动尺度。
- 新版通过 20 项 WebAssembly 回归、13 项官方 CLI 宿主检查和 4 项批处理检查。
- 合成细纹及中尺度起伏测试中，相对原图的残差均方误差依次约为 88.7%、53.0%、19.2%。仅证明此测试图上的三档强度分级，不代表真实人像质量评分。
- 已核对 0.7.0 的 `plugin_ui.rs`、`manifest.rs` 和 `filter_dialog.rs`：没有参数联动接口；生成窗口也不显示 manifest 描述。下方七项磨皮参数仅适用于自定义，详见 README。
- 宿主 `plugin.run` 预览可走缩小的代理文档；插件没有代理倍率信息。新版没有改变这一宿主行为，也没有完成新版桌面预览与真实人像观感验证。
- `proxy.rs` 确认“首选项 → 性能 → Low Resolution Previews”关闭后使用完整分辨率；默认开启时大于 5 MP 的文档缩小预览。README 已补充此设置，本次没有更改用户首选项。
- 当前进程是否使用新版，须通过重新安装 `dist/PortraitCraft.wasm` 确认；本次未操作正在运行的桌面应用。
